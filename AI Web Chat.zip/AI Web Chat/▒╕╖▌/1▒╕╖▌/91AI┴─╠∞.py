from flask import Flask, render_template, request, Response  # 引入Flask相关模块
import ollama  # 引入ollama库，用于与AI模型交互
import logging  # 引入logging模块，用于日志记录
import socket  # 引入socket模块，用于获取IPv6地址
from datetime import datetime  # 引入datetime模块，用于时间处理
import logging
import codecs
import os

class UTF8Handler(logging.FileHandler):
    def __init__(self, filename, mode='a', encoding=None, delay=False):
        super().__init__(filename, mode, encoding=encoding, delay=delay)
        self.stream = codecs.open(filename, mode, encoding='utf-8')

# 初始化Flask应用
app = Flask(__name__, template_folder='.')  # 设置模板文件夹为当前目录


def get_ipv6_address():
    # 获取有效的IPv6地址
    # 使用socket库获取主机名相关的地址信息
    interfaces = socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET6)
    for interface in interfaces:
        ipv6_address = interface[4][0]  # 提取IPv6地址
        # 排除本地回环地址（::1）和链路本地地址（fe80:）
        if not ipv6_address.startswith(('::1', 'fe80:')):
            return ipv6_address
    return None  # 如果没有找到有效的IPv6地址，则返回None

modname = 'deepseek-r1:14b'
# huihui_ai/deepseek-r1-abliterated:8b
# deepseek-r1:1.5b
# deepseek-r1:7b
# deepseek-r1:8b
# deepseek-r1:14b

"""
# 配置日志记录
logging.basicConfig(
    level=logging.INFO,  # 设置日志级别为INFO
    format='%(asctime)s - %(levelname)s - %(message)s',  # 日志格式：时间 - 日志级别 - 消息
    handlers=[
        logging.FileHandler('chat.log'),  # 将日志写入文件chat.log
        logging.StreamHandler()  # 同时在控制台输出日志
    ]
)
"""
# 配置日志记录
logging.basicConfig(
    level=logging.INFO,  # 设置日志级别为INFO
    format='%(asctime)s - %(levelname)s - %(message)s',  # 日志格式：时间 - 日志级别 - 消息
    handlers=[
        UTF8Handler('chat.log'),  # 使用自定义的UTF8Handler
        logging.StreamHandler()  # 同时在控制台输出日志
    ]
)

options = {
    "temperature": 0.6,
    "max_tokens": 512,
    "top_p": 0.9,
}

def chat_ollama(user_message, stream):
    """
    与Ollama服务交互，发送用户消息，并接收响应。
    :param user_message: 用户输入的消息
    :param stream: 是否以流式方式返回数据
    :return: 响应数据
    """
    host = 'http://localhost:11434'  # 设置Ollama服务的地址
    cli = ollama.Client(host=host)  # 初始化Ollama客户端
    # 调用模型的chat接口，发送用户消息
    response = cli.chat(
        model=modname,  # 指定使用的模型
        messages=[{'role': 'user', 'content': user_message}],  # 消息内容，角色为用户
        stream=stream,  # 是否以流式方式返回响应
        # options=options
    )
    return response


def save_chat_record(user_message, ai_response):
    """
    新增函数：保存聊天记录到指定文件
    """
    # 创建chatlist目录（如果不存在）
    os.makedirs('chatlist', exist_ok=True)

    # 生成日期文件名
    date_str = datetime.now().strftime("%Y%m%d")
    filename = os.path.join('chatlist', f"{date_str}.txt")

    # 写入记录（追加模式）
    with codecs.open(filename, 'a', encoding='utf-8') as f:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        record = f"[{timestamp}] User: {user_message}\nAI: {ai_response}\n\n"
        f.write(record)

@app.route('/')
def index():
    """
    首页路由，返回index.html文件
    """
    return render_template('index.html',ipv6_address=ipv6_address)


@app.route('/api/chat', methods=['POST'])
def chat():
    """
    聊天接口，接收前端发送的用户消息，并返回AI的响应。
    """

    def generate(user_message):
        """
        生成器函数，用于流式返回AI响应。
        :param user_message: 用户输入的消息
        """
        try:
            app.logger.info(f"流式处理开始: {user_message[:50]}...")  # 记录日志，表示开始处理消息

            # 调用chat_ollama函数，与AI模型交互
            stream = chat_ollama(user_message, True)
            full_response = ""  # 用于拼接完整的AI响应

            for chunk in stream:  # 遍历流式返回的每个数据块
                content = chunk['message']['content']  # 提取数据块中的内容
                # 处理AI响应中的特殊标记（如<think>表示思考过程）
                if content.startswith('<think>'):
                    content = content.replace('<think>', '', 1)
                elif content.startswith('</think>'):
                    content = content.replace('</think>', '\n', 1)
                app.logger.debug(f"发送数据块: {content}")  # 记录日志，表示发送了某个数据块
                yield f"{content}"  # 使用yield返回数据块，支持流式响应
                full_response += content  # 拼接响应内容

            app.logger.info("流式处理完成")  # 记录日志，表示流式处理完成
            # 保存完整记录（用户消息和AI完整响应）
            save_chat_record(user_message, full_response.strip())

        except Exception as e:
            app.logger.error(f"流式错误: {str(e)}")  # 如果发生异常，记录错误日志
            yield f"[ERROR] {str(e)}\n\n"  # 返回错误信息给前端

    # 使用Flask的Response对象返回流式数据
    return Response(generate(request.json['message']), mimetype='text/event-stream')


if __name__ == '__main__':
    # 获取IPv6地址，如果找不到则回退到localhost
    ipv6_address = get_ipv6_address()
    if ipv6_address:
        app.run(host=ipv6_address, port=91, debug=True, threaded=True)  # 使用IPv6地址启动服务
    else:
        print("No valid IPv6 address found. Falling back to localhost.")  # 提示没有找到IPv6地址
        app.run(host='localhost', port=91, debug=True, threaded=True)  # 回退到localhost启动服务

#ollama create test -f "F:\Ollama\Modelfile\test001"
