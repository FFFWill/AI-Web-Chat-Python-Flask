# -*- coding: utf-8 -*-
"""基于Flask的AI聊天服务，集成ollama大模型、对话历史记录和知识库查询功能"""

# 基础库导入
from flask import Flask, render_template, request, Response, jsonify
import ollama
import logging
import socket
from datetime import datetime
import codecs
import os
import re

# 自定义日志处理器（支持UTF-8编码）
class UTF8Handler(logging.FileHandler):
    """处理UTF-8编码的日志文件"""
    def __init__(self, filename, mode='a', encoding=None, delay=False):
        super().__init__(filename, mode, encoding=encoding, delay=delay)
        self.stream = codecs.open(filename, mode, encoding='utf-8')

# 初始化Flask应用
app = Flask(__name__, template_folder='.')

# 网络配置相关函数
def get_ipv6_address():
    """获取有效的IPv6地址（排除本地回环地址）"""
    interfaces = socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET6)
    for interface in interfaces:
        ipv6_address = interface[4][0]
        if not ipv6_address.startswith(('::1', 'fe80:')):
            return ipv6_address
    return None

# 日志配置（集中配置日志相关）
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        UTF8Handler('chat.log'),  # 文件日志
        logging.StreamHandler()   # 控制台输出
    ]
)

# 核心AI交互函数
def chat_ollama(user_message, stream):
    """通过ollama客户端发送请求并获取流式响应"""
    host = 'http://localhost:11434'
    cli = ollama.Client(host=host)
    response = cli.chat(
        model=modname,
        messages=[{'role': 'user', 'content': user_message}],
        stream=stream
        # options=options
    )
    return response

# 对话记录相关函数（集中处理对话存储）
def save_chat_record(user_message, ai_response):
    """保存对话记录到日期文件（自动清理思考过程）"""
    os.makedirs('chatlist', exist_ok=True)
    date_str = datetime.now().strftime("%Y%m%d")
    filename = os.path.join('chatlist', f"{date_str}.txt")

    # 清理AI回复中的思考过程
    cleaned_response = re.sub(
        r'###正在思考###.*?###总结部分###',  # 匹配思考标记及中间内容
        '',
        ai_response,
        flags=re.DOTALL  # 允许.匹配换行符
    ).strip()  # 去除首尾空白

    with codecs.open(filename, 'a', encoding='utf-8') as f:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        # 使用清理后的回复
        record = f"[{timestamp}] 用户: {user_message}\nAI: {cleaned_response}\n\n"
        f.write(record)

def get_chat_records(date_str, num_records=5):
    """获取指定日期的历史对话记录"""
    filename = os.path.join('chatlist', f"{date_str}.txt")

    if not os.path.exists(filename):
        app.logger.warning(f"历史记录文件 {filename} 不存在")
        return []

    try:
        with codecs.open(filename, 'r', encoding='utf-8') as f:
            lines = f.read()

        # 使用正则表达式匹配单条记录
        records = re.findall(r'\[.*?\]\s*用户:.*?\nAI:.*?(?=\n\n|\Z)', lines, re.DOTALL)
        if records:
            app.logger.info(f"读取到 {len(records)} 条历史记录")
            return records[-num_records:] if num_records > 0 else []  # 返回最新的 num_records 条记录
        else:
            app.logger.warning("未找到匹配的历史记录")
            return []
    except Exception as e:
        app.logger.error(f"读取历史记录失败: {str(e)}")
        return []

# 知识库查询相关函数（集中处理知识匹配）
# 知识库查询相关函数（集中处理知识匹配）
def find_best_matches(user_query):
    """查找多个匹配的文件内容，返回匹配度最高的文件"""
    folder_path = 'listku/processed_listku'
    if not os.path.exists(folder_path):
        app.logger.warning("知识库文件夹不存在")
        return []

    files = os.listdir(folder_path)
    if not files:
        app.logger.warning("知识库文件夹为空")
        return []

    matches = []

    # 将用户查询拆分为单个字符
    query_chars = set(user_query.lower())

    # 遍历文件夹中的每个文件
    for filename in files:
        if not filename.endswith('.txt'):
            continue

        # 去掉文件扩展名，只保留文件名用于匹配
        base_filename = os.path.splitext(filename)[0].lower()

        # 计算匹配分数（保持原有逻辑）
        score = 0
        for char in query_chars:
            if char in base_filename:
                score += base_filename.count(char) * 2

        # 额外加分：如果文件名包含完整的查询单词
        for word in user_query.lower().split():
            if word in base_filename:
                score += len(word) * 3

        # 如果分数大于0，则认为是匹配
        if score > threshold:
            try:
                with codecs.open(os.path.join(folder_path, filename), 'r', encoding='utf-8') as f:
                    # 新增内容清洗步骤
                    content = re.sub(r'\s+', ' ', f.read().strip())  # 合并多余空白
                    content = content.replace('\n', ' ')  # 移除换行符
                    if not content.strip():  # 跳过空内容
                        continue
                    matches.append((filename, content, score))
            except Exception as e:
                app.logger.error(f"读取知识库文件失败: {str(e)}")

    # 按匹配分数排序
    matches.sort(key=lambda x: x[2], reverse=True)
    return matches[:max_results]

# Web路由处理（集中处理HTTP请求）
@app.route('/')
def index():
    """根路由，返回主界面"""
    return render_template('index.html', ipv6_address=get_ipv6_address())

@app.route('/api/chat', methods=['POST'])
def chat():
    """处理聊天请求"""
    use_memory = request.json.get('useMemory', False)
    use_database = request.json.get('useDatabase', False)
    user_message = request.json['message']
    num_history_records = re_chatlist#request.json.get('numHistoryRecords', re_chatlist)  # 默认最多引用5条历史记录
    #max_results = re_listku#request.json.get('max_results', re_listku)  # 默认返回最多2条匹配
    max_content_length = re_max_listku#request.json.get('max_content_length', re_max_listku)  # 默认每条内容最多100字符

    # 构建历史记录上下文
    history_parts = []
    if use_memory:
        today_str = datetime.now().strftime("%Y%m%d")
        matched_records = get_chat_records(today_str, num_history_records)
        for i, record in enumerate(matched_records, start=1):
            history_parts.append(f"[历史对话 {i}]:\n{record}")

    if use_database:
        matched_files = find_best_matches(user_message)
        matched_files = matched_files[:max_results]
        for i, (filename, content, match_ratio) in enumerate(matched_files, start=1):
            # 优化后的截断逻辑
            trimmed_content = content[:max_content_length]
            if len(content) > max_content_length:
                trimmed_content += '...'
            # 确保截断后内容有效
            if not trimmed_content.strip():
                continue

            history_parts.append(f"[数据库资料 {i} - {filename} (关联性: {match_ratio:.2f})]:\n{trimmed_content}")

    # ... [保持后续逻辑不变]

    # 合并历史记录到输入上下文
    full_history = "\n\n".join(history_parts) if history_parts else ""
    full_content = f"{user_message}\n\n{full_history}" if full_history else user_message

    # 流式响应生成器
    def generate(content):
        try:
            app.logger.info(f"流式处理开始: {content[:50]}...")
            stream = chat_ollama(content, True)
            full_response = ""

            # 添加历史记录提示（优化格式）
            if history_parts:
                yield "\n📌 正在参考以下信息：\n"
                for part in history_parts:
                    yield f"{part}\n\n"

            # 添加思考过程提示
            yield "💡 AI思考过程：\n"

            for chunk in stream:
                content = chunk['message']['content']
                if content.startswith('<think>'):
                    content = content.replace('<think>', '###正在思考###', 1)
                elif content.startswith('</think>'):
                    content = content.replace('</think>', '###总结部分###', 1)
                app.logger.debug(f"发送数据块: {content}")
                yield f"{content}"
                full_response += content

            app.logger.info("流式处理完成")
            save_chat_record(user_message, full_response.strip())
        except GeneratorExit:
            app.logger.warning("客户端断开连接，流式处理中止")
        except Exception as e:
            app.logger.error(f"流式错误: {str(e)}")
            yield f"[ERROR] {str(e)}\n\n"

    return Response(generate(full_content), mimetype='text/event-stream')

# 主程序入口
if __name__ == '__main__':
    max_results = 2 # 最多返回数据库
    #re_listku = 2 # 最多返回数据库
    re_chatlist = 1 # 最多返回历史记录
    re_max_listku = 100 # 最大返回资料库字数,单份
    threshold = 5 # 阈值,越大越严格
    modname = 'huihui_ai/deepseek-r1-abliterated:8b' # 模型选择
    # huihui_ai/deepseek-r1-abliterated:8b  #无限制
    # deepseek-r1:1.5b                      #官方
    # deepseek-r1:7b
    # deepseek-r1:8b
    # deepseek-r1:14b

    options = {
        "temperature": 0.6,         # 控制生成文本的随机性,值越低越保守.更多地控制着模型输出的"冷静度"或"热情度",即输出的随机性程度.
        "max_tokens": 512,          # 限制生成文本的最大长度(token).
        "top_p": 0.9,               # top_p采样,模型会生成一组候选 token 然后从累积概率达到或超过'p'的 token 中随机选择一个作为输出.随机性,创造性.
        "top_k": 100,               # 从模型认为最可能的"k"个词中选择下一个词."k"值越大,选择范围越广,生成的文本越多样;"k"值越小,选择范围越窄,生成的文本越趋向于高概率的词.
        #"presence penalty": 0,     #0-1.5轻惩罚,2强惩罚,一种固定的惩罚,如果一个token已经在文本中出现过,就会受到惩罚.这会导致模型引入更多新的token/单词/短语,从而使其讨论的主题更加多样化,话题变化更加频繁,而不会明显抑制常用词的重复.
        #"frequency penalty": 0,    #频率惩罚,让token每次在文本中出现都受到惩罚.这可以阻止重复使用相同的token/单词/短语,同时也会使模型讨论的主题更加多样化,更频繁地更换主题.
    }

    ipv6_address = get_ipv6_address()
    if ipv6_address:
        app.run(host=ipv6_address, port=91, debug=True, threaded=True)
    else:
        print("No valid IPv6 address found. Falling back to localhost.")
        app.run(host='localhost', port=91, debug=True, threaded=True)
