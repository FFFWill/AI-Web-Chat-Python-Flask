from flask import Flask, render_template, request, Response, jsonify
import ollama
import logging
import socket
from datetime import datetime
import codecs
import os


class UTF8Handler(logging.FileHandler):
    def __init__(self, filename, mode='a', encoding=None, delay=False):
        super().__init__(filename, mode, encoding=encoding, delay=delay)
        self.stream = codecs.open(filename, mode, encoding='utf-8')


app = Flask(__name__, template_folder='.')


def get_ipv6_address():
    interfaces = socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET6)
    for interface in interfaces:
        ipv6_address = interface[4][0]
        if not ipv6_address.startswith(('::1', 'fe80:')):
            return ipv6_address
    return None


modname = 'huihui_ai/deepseek-r1-abliterated:8b'
# huihui_ai/deepseek-r1-abliterated:8b
# deepseek-r1:1.5b
# deepseek-r1:7b
# deepseek-r1:8b
# deepseek-r1:14b

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        UTF8Handler('chat.log'),
        logging.StreamHandler()
    ]
)

options = {
    "temperature": 0.6,
    "max_tokens": 512,
    "top_p": 0.9,
}


def chat_ollama(user_message, stream):
    host = 'http://localhost:11434'
    cli = ollama.Client(host=host)
    response = cli.chat(
        model=modname,
        messages=[{'role': 'user', 'content': user_message}],
        stream=stream
    )
    return response


def save_chat_record(user_message, ai_response):
    os.makedirs('chatlist', exist_ok=True)
    date_str = datetime.now().strftime("%Y%m%d")
    filename = os.path.join('chatlist', f"{date_str}.txt")

    with codecs.open(filename, 'a', encoding='utf-8') as f:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        record = f"[{timestamp}] User: {user_message}\nAI: {ai_response}\n\n"
        f.write(record)


def get_last_chat_record():
    """获取当天最后一条完整聊天记录（包括用户和AI的对话）"""
    date_str = datetime.now().strftime("%Y%m%d")
    filename = os.path.join('chatlist', f"{date_str}.txt")

    if not os.path.exists(filename):
        return None

    with codecs.open(filename, 'r', encoding='utf-8') as f:
        lines = f.read()  # 直接读取全部内容

    # 使用正则表达式匹配最后一条完整记录（以两个换行结尾）
    import re
    records = re.findall(r'\[.*?\]\s*User:.*?\nAI:.*?(?=\n\n|\Z)', lines, re.DOTALL)

    return records[-1] if records else None  # 返回最后一条完整记录


@app.route('/')
def index():
    return render_template('index.html', ipv6_address=ipv6_address)


@app.route('/api/chat', methods=['POST'])
def chat():
    use_memory = request.json.get('useMemory', False)
    user_message = request.json['message']

    # 获取历史记录
    history = ""
    if use_memory:
        last_record = get_last_chat_record()
        if last_record:
            # 将完整历史记录与新问题拼接
            history = f"历史对话：\n{last_record}\n\n当前问题：\n{user_message}"
        else:
            history = user_message
    else:
        history = user_message

    def generate(content):
        try:
            app.logger.info(f"流式处理开始: {content[:50]}...")
            stream = chat_ollama(content, True)
            full_response = ""

            for chunk in stream:
                content = chunk['message']['content']
                if content.startswith('<think>'):
                    content = content.replace('<think>', '', 1)
                elif content.startswith('</think>'):
                    content = content.replace('</think>', '\n', 1)
                app.logger.debug(f"发送数据块: {content}")
                yield f"{content}"
                full_response += content

            app.logger.info("流式处理完成")
            save_chat_record(user_message, full_response.strip())
        except Exception as e:
            app.logger.error(f"流式错误: {str(e)}")
            yield f"[ERROR] {str(e)}\n\n"

    return Response(generate(history), mimetype='text/event-stream')


if __name__ == '__main__':
    ipv6_address = get_ipv6_address()
    if ipv6_address:
        app.run(host=ipv6_address, port=91, debug=True, threaded=True)
    else:
        print("No valid IPv6 address found. Falling back to localhost.")
        app.run(host='localhost', port=91, debug=True, threaded=True)