# -*- coding: utf-8 -*-
"""基于Flask的AI聊天服务，集成ollama大模型、对话历史记录和知识库查询功能、函数执行后返回功能。"""

from flask import Flask, render_template, request, Response
import ollama
import logging
import socket
from datetime import datetime
import codecs
import os
import re
import subprocess


# 自定义日志处理器（支持UTF-8编码）
class UTF8Handler(logging.FileHandler):
    """处理UTF-8编码的日志文件"""
    def __init__(self, filename, mode='a', encoding=None, delay=False):
        super().__init__(filename, mode, encoding=encoding, delay=delay)
        self.stream = codecs.open(filename, mode, encoding='utf-8')  # 强制使用UTF-8编码打开文件流

"""
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('chat.log', encoding='utf-8'),  # 直接指定编码
        logging.StreamHandler()
    ]
)
"""

# 初始化Flask应用
app = Flask(__name__, template_folder='.')  # 设置模板文件夹为当前目录


def get_ipv6_address():#获取ipv6长地址,一个元组
    output = os.popen("ipconfig /all").read()
    # print(output)
    result = re.findall(r"(([a-f0-9]{1,4}:){7}[a-f0-9]{1,4})", output, re.I)
    ipv6_address = result[0][0]
    return ipv6_address


# 日志配置（集中配置日志相关）
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        UTF8Handler('chat.log'),  # 文件日志处理器
        logging.StreamHandler()    # 控制台输出处理器
    ]
)


# 核心AI交互函数
def chat_ollama(user_message, stream):
    """通过ollama客户端发送请求并获取流式响应"""
    host = 'http://localhost:11434'  # ollama服务地址
    cli = ollama.Client(host=host)
    response = cli.chat(
        model=modname,                # 使用预定义的模型名称
        messages=[{'role': 'user', 'content': user_message}],  # 用户消息列表
        stream=stream                 # 是否启用流式响应
        # options=options
    )
    return response


# 对话记录相关函数（集中处理对话存储）
def save_chat_record(user_message, ai_response):
    """保存对话记录到日期文件（自动清理思考过程）"""
    os.makedirs('chatlist', exist_ok=True)  # 确保目录存在
    date_str = datetime.now().strftime("%Y%m%d")
    filename = os.path.join('chatlist', f"{date_str}.txt")

    # 清理AI回复中的思考过程（正则表达式匹配特定标记）
    cleaned_response = re.sub(
        r'###正在思考###.*?###总结部分###',  # 匹配思考标记及中间内容
        '',
        ai_response,
        flags=re.DOTALL  # 允许.匹配换行符
    ).strip()  # 去除首尾空白

    with codecs.open(filename, 'a', encoding='utf-8') as f:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        record = f"[{timestamp}] 用户的问题: {user_message}\nAI回复: {cleaned_response}###RECORD_SEPARATOR###\n"

        f.write(record)


def get_chat_records(date_str, num_records=5):
    """获取指定日期的历史对话记录（新增字数截断）"""
    filename = os.path.join('chatlist', f"{date_str}.txt")

    if not os.path.exists(filename):
        app.logger.warning(f"历史记录文件 {filename} 不存在")
        return []

    try:
        with codecs.open(filename, 'r', encoding='utf-8') as f:
            lines = f.read()

        pattern = r'\[.*?\]\s*用户的问题:[\s\S]*?AI回复:[\s\S]*?(?=###RECORD_SEPARATOR###|\Z)'
        records = re.findall(pattern, lines, re.DOTALL)
        if records:
            app.logger.info(f"读取到 {len(records)} 条历史记录")
            # 新增截断逻辑
            processed_records = []
            for record in records[-num_records:]:
                if len(record) > max_history_length:
                    trimmed_record = record[:max_history_length] + '...'
                    app.logger.debug(f"截断历史记录: 原长度{len(record)} → 新长度{len(trimmed_record)}")
                    processed_records.append(trimmed_record)
                else:
                    processed_records.append(record)
            return processed_records
        else:
            app.logger.warning("未找到匹配的历史记录")
            return []
    except Exception as e:
        app.logger.error(f"读取历史记录失败: {str(e)}")
        return []


# 知识库查询相关函数（集中处理知识匹配）
def find_best_matches(user_query):
    """查找多个匹配的文件内容，返回匹配度最高的文件"""
    folder_path = 'listku/processed_listku'
    if not os.path.exists(folder_path):
        app.logger.warning("知识库文件夹不存在")
        return []

    files = os.listdir(folder_path)
    if not files:
        app.logger.warning("知识库文件夹为空")
        return []

    matches = []

    # 将用户查询拆分为单个字符（用于模糊匹配）
    query_chars = set(user_query.lower())

    # 遍历文件夹中的每个文件
    for filename in files:
        if not filename.endswith('.txt'):
            continue

        # 去掉文件扩展名，只保留文件名用于匹配
        base_filename = os.path.splitext(filename)[0].lower()

        # 计算匹配分数（字符匹配和单词匹配）
        score = 0
        for char in query_chars:
            if char in base_filename:
                score += base_filename.count(char) * 2

        # 额外加分：如果文件名包含完整的查询单词
        for word in user_query.lower().split():
            if word in base_filename:
                score += len(word) * 3

        # 如果分数大于阈值，则认为是匹配
        if score > threshold:
            try:
                with codecs.open(os.path.join(folder_path, filename), 'r', encoding='utf-8') as f:
                    # 新增内容清洗步骤
                    content = re.sub(r'\s+', ' ', f.read().strip())  # 合并多余空白
                    content = content.replace('\n', ' ')  # 移除换行符
                    if not content.strip():  # 跳过空内容
                        continue
                    matches.append((filename, content, score))
            except Exception as e:
                app.logger.error(f"读取知识库文件失败: {str(e)}")

    # 按匹配分数排序并返回前max_results个结果
    matches.sort(key=lambda x: x[2], reverse=True)
    return matches[:max_results]


# 新增路由：获取可用函数列表
@app.route('/api/list_funcs', methods=['GET'])
def list_funcs():
    """返回可用的函数列表"""
    try:
        func_dir = 'func'
        actual_files = [f for f in os.listdir(func_dir) if
                        f.endswith('.py') and os.path.isfile(os.path.join(func_dir, f))]
        app.logger.info(f"检测到函数目录文件: {actual_files}")
        return {'funcs': actual_files}
    except Exception as e:
        app.logger.error(f"获取函数列表异常: {str(e)}")
        return {'funcs': []}, 500


# 新增路由：执行指定函数
@app.route('/api/run_func', methods=['GET'])
def run_func():
    func_name = request.args.get('func')
    if not func_name or not func_name.endswith('.py'):
        return "无效的函数请求", 400

    func_path = os.path.join('func', func_name)

    if not os.path.exists(func_path):
        return f"函数文件不存在: {func_path}", 404

    try:
        result = subprocess.run(
            ['python', '-u', func_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding='utf-8',
            timeout=60
        )
        output = result.stdout.strip()
        error = result.stderr.strip()

        if error:
            app.logger.error(f"子进程错误: {error}")
            return f"执行错误: {error}", 500
        return output
    except Exception as e:
        return f"执行错误: {str(e)}", 500


# Web路由处理（集中处理HTTP请求）
@app.route('/')
def index():
    """根路由，返回主界面"""
    return render_template('index.html', ipv6_address=get_ipv6_address())


@app.route('/api/chat', methods=['POST'])
def chat():
    """处理聊天请求"""
    use_memory = request.json.get('useMemory', False)    # 是否使用历史记录
    use_database = request.json.get('useDatabase', False) # 是否查询知识库
    user_message = request.json['message']               # 用户原始消息

    # 获取前端设置
    settings = request.json.get('settings', {})

    # 更新全局配置
    global re_chatlist, max_history_length, max_results, re_max_listku, modname
    re_chatlist = settings.get('re_chatlist', 2)
    max_history_length = settings.get('max_history_length', 200)
    max_results = settings.get('max_results', 2)
    re_max_listku = settings.get('re_max_listku', 150)  # 确保这里使用了自定义值
    modname = settings.get('modname', 'deepseek-r1:8b')

    # 构建历史记录上下文
    history_parts = []
    if use_memory:
        today_str = datetime.now().strftime("%Y%m%d")
        matched_records = get_chat_records(today_str, re_chatlist)
        for i, record in enumerate(matched_records, start=1):
            history_parts.append(f"[历史对话 {i}]:\n{record}")

    if use_database:
        matched_files = find_best_matches(user_message)
        matched_files = matched_files[:max_results]  # 使用max_results
        for i, (filename, content, match_ratio) in enumerate(matched_files, start=1):
            # 优化后的截断逻辑
            trimmed_content = content[:re_max_listku]  # 使用re_max_listku
            if len(content) > re_max_listku:
                trimmed_content += '...'
            # 确保截断后内容有效
            if not trimmed_content.strip():
                continue

            history_parts.append(f"[数据库资料 {i} - {filename} (关联性: {match_ratio:.2f})]:\n{trimmed_content}")



    # 合并历史记录到输入上下文
    full_history = "\n\n".join(history_parts) if history_parts else ""
    full_content = f"{user_message}\n\n{full_history}" if full_history else user_message

    # 在构建full_content时添加函数结果
    if 'currentFunc' in request.json and request.json['currentFunc']:
        func_result = request.json['currentFunc']
        full_content = f"{user_message}\n\n[函数执行结果]:\n{func_result}\n\n{full_history}"
    else:
        full_content = f"{user_message}\n\n{full_history}" if full_history else user_message

    # 流式响应生成器
    def generate(content):
        try:
            app.logger.info(f"流式处理开始: {content[:50]}...")
            stream = chat_ollama(content, True)
            full_response = ""

            # 添加历史记录提示（优化格式）
            yield "\n\n📌 正在参考以下信息：\n\n"
            for part in history_parts:
                yield f"{part.replace('###RECORD_SEPARATOR###', '')}\n\n"  # 移除分隔标记

            # 添加思考过程提示
            yield "💡 AI思考过程：\n"

            for chunk in stream:
                content = chunk['message']['content']
                if content.startswith('<think>'):
                    content = content.replace('<think>', '\n###正在思考###\n', 1)
                elif content.startswith('</think>'):
                    content = content.replace('</think>', '\n###总结部分###\n', 1)
                app.logger.debug(f"发送数据块: {content}")
                yield f"{content}"
                full_response += content

            app.logger.info("流式处理完成")
            save_chat_record(user_message, full_response.strip())
        except GeneratorExit:
            app.logger.warning("客户端断开连接，流式处理中止")
        except Exception as e:
            app.logger.error(f"流式错误: {str(e)}")
            yield f"[ERROR] {str(e)}\n\n"

    return Response(generate(full_content), mimetype='text/event-stream')


# 主程序入口
if __name__ == '__main__':
    # 配置参数（集中管理）
    #max_results = 2          # 最多返回数据库结果数
    #re_max_listku = 150      # 最大返回单份资料库字数
    threshold = 15            # 数据库单份得分阈值（越大越严格）

    #re_chatlist = 2  # 最多引用历史记录数
    #max_history_length = 200  # 历史记录单条最大长度
    #modname = 'deepseek-r1:8b'    # 模型选择
    # huihui_ai/deepseek-r1-abliterated:8b              #无限制
    # deepseek-r1:1.5b                                  #官方
    # deepseek-r1:7b
    # deepseek-r1:8b
    # deepseek-r1:14b

    # ollama生成参数配置
    options = {
        "temperature": 0.6,             # 控制生成文本的随机性,值越低越保守.更多地控制着模型输出的"冷静度"或"热情度",即输出的随机性程度.
        "max_tokens": 512,              # 限制生成文本的最大长度(token).
        "top_p": 0.9,                   # top_p采样,模型会生成一组候选 token 然后从累积概率达到或超过'p'的 token 中随机选择一个作为输出.随机性,创造性.
        "top_k": 100,                   # 从模型认为最可能的"k"个词中选择下一个词."k"值越大,选择范围越广,生成的文本越多样;"k"值越小,选择范围越窄,生成的文本越趋向于高概率的词.
        # "presence penalty": 0,        #0-1.5轻惩罚,2强惩罚,一种固定的惩罚,如果一个token已经在文本中出现过,就会受到惩罚.这会导致模型引入更多新的token/单词/短语,从而使其讨论的主题更加多样化,话题变化更加频繁,而不会明显抑制常用词的重复.
        # "frequency penalty": 0,       #频率惩罚,让token每次在文本中出现都受到惩罚.这可以阻止重复使用相同的token/单词/短语,同时也会使模型讨论的主题更加多样化,更频繁地更换主题.
    }

    # 获取IPv6地址并启动服务
    ipv6_address = get_ipv6_address()
    if ipv6_address:
        app.run(host=ipv6_address, port=91, debug=True, threaded=True)
    else:
        print("No valid IPv6 address found. Falling back to localhost.")
        app.run(host='localhost', port=91, debug=True, threaded=True)